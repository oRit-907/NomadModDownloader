BepInEx 5 runtime (5.4.23.5, MIT licence, https://github.com/BepInEx/BepInEx) used by "BepInEx 5 Compatibility"
(BepInEx\plugins\BepInEx5Compat) to run BepInEx 5 mods on BepInEx 6. Its settings are in BepInEx\config\BepInEx5.cfg.
